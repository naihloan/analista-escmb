﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManuelBelgrano.Consola
{
    class ProgramaPitagoras
    {
        public void IniciarPrograma() {
            //ingresar los lados CA, CO de un triángulo
            //rectángulo y calcular la Hipotenusa
            //utilizándo el teorema 
            //de Pitágoras
            //H2 = CA2 + CO2
            //double HP, CA, CO;
            //string ingresoCA = "2";
            //CA = double.Parse(ingresoCA);
            //CA = CA * CA;
            ////también pueden usar 
            //CA = Math.Pow(CA, CO);
            //HP = Math.Sqrt(CA + CO);
        }
    }
}
