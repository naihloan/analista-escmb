﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManuelBelgrano.Vehiculo
{
    public class Auto : IVehiculo
    {
        public void Acelerar()
        {
            throw new NotImplementedException();
        }

        public void Frenar()
        {
            throw new NotImplementedException();
        }

        public void MostrarForma()
        {
            throw new NotImplementedException();
        }
    }
}
