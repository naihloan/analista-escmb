using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManuelBelgrano.App
{
    class Program
    {
        static void Main(string[] args)
        {
            /*1)Generar&nbsp;un&nbsp;programa&nbsp;que&nbsp;imprima&nbsp;un&nbsp;mensaje&nbsp;que&nbsp;diga&nbsp;:&nbsp;'bienvenidos&nbsp;al&nbsp;programa&nbsp;del&nbsp;primer&nbsp;parcial'<br>2)El&nbsp;mismo&nbsp;deberá&nbsp;pedir&nbsp;al&nbsp;usuario&nbsp;que&nbsp;ingrese&nbsp;dos&nbsp;números&nbsp;enteros&nbsp;(validar&nbsp;el&nbsp;ingreso)<br>Luego&nbsp;imprimir&nbsp;el&nbsp;mayor&nbsp;de&nbsp;ambos,&nbsp;la&nbsp;suma&nbsp;de&nbsp;ambos&nbsp;y&nbsp;el&nbsp;promedio&nbsp;de&nbsp;ambos<br>Si&nbsp;son&nbsp;iguales,&nbsp;imprimir&nbsp;la&nbsp;suma&nbsp;de&nbsp;ambos&nbsp;elevado&nbsp;al&nbsp;cuadrado&nbsp;(Math.Pow())<br>3)Pedir&nbsp;que&nbsp;el&nbsp;usuario&nbsp;ingrese&nbsp;una&nbsp;variable&nbsp;llamada&nbsp;max,&nbsp;y&nbsp;luego&nbsp;imprimir&nbsp;todos&nbsp;los&nbsp;números<br>del&nbsp;1&nbsp;al&nbsp;max&nbsp;(inclusive)<br>4)&nbsp;Al&nbsp;finalizar,&nbsp;preguntar&nbsp;al&nbsp;usuario&nbsp;si&nbsp;desea&nbsp;limpiar&nbsp;la&nbsp;consola<br>5)&nbsp;Preguntar&nbsp;al&nbsp;usuario&nbsp;si&nbsp;desea&nbsp;volver&nbsp;a&nbsp;ejecutar&nbsp;el&nbsp;programa&nbsp;o&nbsp;salir<br>*/


            //NO REMOVER ESTA LINEA - ignorar el error!!!!
            Examen.Examen.Empezar();

            //escribe tu codigo desde aqui




            //NO REMOVER ESTA LINEA - ignorar el error!!!!
            Examen.Examen.Finalizar();
        }
    }
}
