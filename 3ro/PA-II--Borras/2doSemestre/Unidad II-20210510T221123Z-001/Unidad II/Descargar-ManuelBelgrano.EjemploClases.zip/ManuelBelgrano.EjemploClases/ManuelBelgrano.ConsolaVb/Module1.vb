﻿Module Module1

    Sub Main()

        Dim primerNombre As String
        Dim segundoNombre As String
        Dim nombreCompleto As String
        Dim edad As Integer
        edad = 1


        primerNombre = "Javier" 'este es mi primer nombre
        segundoNombre = "Mc Donald's"

        If edad >= 21 Then
            Console.WriteLine("Puede tomar alcohol")
        ElseIf edad >= 18 Then
            Console.WriteLine("Puede fumar")
        ElseIf edad < 18 AndAlso edad > 3 Then
            Console.WriteLine("Puede jugar a la pelota o al tejo")
        Else
            Console.WriteLine("No cumple con las condiciones ante4riores")
        End If
        If primerNombre = "javier" Then
            Console.WriteLine("El nombre es copado")
        End If
        If primerNombre = "Javier" Then
            Console.WriteLine("El nombre es copado")
        End If

        nombreCompleto = primerNombre _
        & " " + segundoNombre


        Console.WriteLine(nombreCompleto)

        Console.ReadLine()


    End Sub

End Module
