﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManuelBelgrano.EjemploClases
{
    public class Transporte
    {
        public void Acelerar() { }
    }
}
