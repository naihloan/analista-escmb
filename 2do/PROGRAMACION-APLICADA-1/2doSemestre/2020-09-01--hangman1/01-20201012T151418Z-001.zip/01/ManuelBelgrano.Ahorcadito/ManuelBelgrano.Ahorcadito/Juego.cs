﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManuelBelgrano.Ahorcadito
{
    public class Juego
    {
        public string Palabra { get; set; }
        public string NombreJugador { get; set; }
        public int CaracteresCorrectos { get; set; }
        public int CaracteresIncorrectos { get; set; }

        public void IngresarCaracter() { }

        void MostrarCaracteresCorrectos() { }

        void MostrarMonigote() { }


    }
}
